package com.rizky.btchat

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class ChatMsg(
    val id: Long,
    val mine: Boolean,
    val text: String? = null,
    val fileName: String? = null,
    val filePath: String? = null,
    val fileSize: Long = 0,
    val time: Long = System.currentTimeMillis()
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val prefs = ctx.getSharedPreferences("btchat", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var manager: BtManager? = null

    val messages = mutableStateListOf<ChatMsg>()
    var state by mutableStateOf(ConnState.IDLE); private set
    var peerName by mutableStateOf(prefs.getString("peer_name", null)); private set
    var peerAddress by mutableStateOf(prefs.getString("peer_addr", null)); private set
    var background by mutableStateOf<ImageBitmap?>(null); private set
    var progress by mutableStateOf<Float?>(null); private set
    var sending by mutableStateOf(false); private set

    private val listener = object : BtManager.Listener {
        override fun onState(s: ConnState) { state = s }
        override fun onText(text: String) { add(ChatMsg(newId(), false, text = text)) }
        override fun onFile(name: String, file: File, size: Long) {
            add(ChatMsg(newId(), false, fileName = name, filePath = file.absolutePath, fileSize = size))
        }
        override fun onProgress(sending: Boolean, fraction: Float?) {
            this@ChatViewModel.sending = sending
            progress = fraction
        }
    }

    init {
        loadHistory()
        loadBackground()
    }

    private fun newId() = System.nanoTime()

    // ---------- Koneksi ----------
    fun start() {
        val addr = peerAddress ?: return
        if (manager != null) return
        manager = BtManager(ctx, listener).also { it.start(addr) }
    }

    private fun stopManager() { manager?.stop(); manager = null; state = ConnState.IDLE }

    fun setPeer(name: String, address: String) {
        stopManager()
        prefs.edit().putString("peer_name", name).putString("peer_addr", address).apply()
        peerName = name; peerAddress = address
    }

    fun forgetPeer() {
        stopManager()
        prefs.edit().remove("peer_name").remove("peer_addr").apply()
        peerName = null; peerAddress = null
    }

    // ---------- Kirim ----------
    fun sendText(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        if (state != ConnState.CONNECTED) { toast("Belum tersambung ke HP lawan"); return }
        io.execute {
            val ok = manager?.sendText(text) ?: false
            main.post { if (ok) add(ChatMsg(newId(), true, text = text)) else toast("Gagal mengirim pesan") }
        }
    }

    fun sendFile(uri: Uri) {
        if (state != ConnState.CONNECTED) { toast("Belum tersambung ke HP lawan"); return }
        io.execute {
            try {
                val name = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getString(0) else null }
                    ?: "file_${System.currentTimeMillis()}"
                val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "sent").apply { mkdirs() }
                val local = uniqueFile(dir, name)
                ctx.contentResolver.openInputStream(uri)?.use { i -> local.outputStream().use { i.copyTo(it) } }
                    ?: throw IllegalStateException("File tidak bisa dibuka")
                val ok = manager?.sendFile(local, name) ?: false
                main.post {
                    if (ok) add(ChatMsg(newId(), true, fileName = name, filePath = local.absolutePath, fileSize = local.length()))
                    else toast("Gagal mengirim file")
                }
            } catch (e: Exception) {
                main.post { toast("Gagal mengirim file") }
            }
        }
    }

    // ---------- Latar obrolan ----------
    fun setBackground(uri: Uri) {
        thread {
            val bmp = decodeUri(ctx, uri, 1600) ?: return@thread
            File(ctx.filesDir, "chat_bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val ib = bmp.asImageBitmap()
            main.post { background = ib }
        }
    }

    fun resetBackground() {
        File(ctx.filesDir, "chat_bg.jpg").delete()
        background = null
    }

    private fun loadBackground() {
        val f = File(ctx.filesDir, "chat_bg.jpg")
        if (f.exists()) decodeFile(f.absolutePath, 1600)?.let { background = it.asImageBitmap() }
    }

    // ---------- Riwayat ----------
    private fun add(m: ChatMsg) { messages.add(m); saveHistory() }

    fun clearHistory() { messages.clear(); saveHistory() }

    private fun saveHistory() {
        val arr = JSONArray()
        messages.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("mine", m.mine); put("time", m.time); put("size", m.fileSize)
                m.text?.let { put("text", it) }
                m.fileName?.let { put("fn", it) }
                m.filePath?.let { put("fp", it) }
            })
        }
        runCatching { File(ctx.filesDir, "history.json").writeText(arr.toString()) }
    }

    private fun loadHistory() {
        val f = File(ctx.filesDir, "history.json")
        if (!f.exists()) return
        runCatching {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(
                    ChatMsg(
                        id = o.getLong("id"), mine = o.getBoolean("mine"),
                        text = o.optString("text").ifEmpty { null },
                        fileName = o.optString("fn").ifEmpty { null },
                        filePath = o.optString("fp").ifEmpty { null },
                        fileSize = o.optLong("size"), time = o.optLong("time")
                    )
                )
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    override fun onCleared() { manager?.stop(); io.shutdown() }
}

package com.rizky.btchat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.*
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.random.Random

enum class ConnState { IDLE, CONNECTING, CONNECTED }

/**
 * Bluetooth Classic (RFCOMM). Kedua HP menjalankan server SEKALIGUS mencoba terhubung
 * ke HP pasangan yang tersimpan, jadi sambungan otomatis terbentuk begitu kedua app dibuka.
 *
 * Protokol: [1][len][utf8]                    -> pesan teks
 *           [2][len][nama][size:long][bytes]  -> file
 */
@SuppressLint("MissingPermission")
class BtManager(private val ctx: Context, private val listener: Listener) {

    interface Listener {
        fun onState(s: ConnState)
        fun onText(text: String)
        fun onFile(name: String, file: File, size: Long)
        fun onProgress(sending: Boolean, fraction: Float?)
    }

    companion object {
        val APP_UUID: UUID = UUID.fromString("8f3c6d1e-5b2a-4c7e-9a41-2d6b7e0f1a35")
    }

    private val main = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    @Volatile private var running = false
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: DataOutputStream? = null
    @Volatile private var server: BluetoothServerSocket? = null
    private val writeLock = Any()

    private fun post(block: () -> Unit) { main.post(block) }

    fun start(peerAddress: String) {
        if (running) return
        running = true

        // 1) Mode "menunggu": terima sambungan dari HP lawan
        thread(name = "bt-accept", isDaemon = true) {
            while (running) {
                try {
                    val s = adapter?.listenUsingRfcommWithServiceRecord("BtChat", APP_UUID)
                        ?: throw IOException("Bluetooth tidak tersedia")
                    server = s
                    while (running) attach(s.accept())
                } catch (e: Exception) {
                    runCatching { server?.close() }
                    if (running) Thread.sleep(1500)
                }
            }
        }

        // 2) Mode "menghubungi": coba sambung otomatis ke HP pasangan
        thread(name = "bt-connect", isDaemon = true) {
            Thread.sleep(Random.nextLong(200, 1200))
            while (running) {
                if (socket == null && adapter?.isEnabled == true) {
                    post { listener.onState(ConnState.CONNECTING) }
                    try {
                        val dev = adapter.getRemoteDevice(peerAddress)
                        val s = dev.createRfcommSocketToServiceRecord(APP_UUID)
                        s.connect()
                        attach(s)
                    } catch (e: Exception) {
                        Thread.sleep(Random.nextLong(1500, 3500)) // jitter agar tidak tabrakan
                    }
                } else {
                    Thread.sleep(1000)
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        val s = socket
        socket = null; out = null
        runCatching { s?.close() }
    }

    private fun attach(s: BluetoothSocket) {
        synchronized(this) {
            if (socket != null) { runCatching { s.close() }; return }
            socket = s
            out = DataOutputStream(BufferedOutputStream(s.outputStream, 8192))
        }
        post { listener.onState(ConnState.CONNECTED) }
        thread(name = "bt-read", isDaemon = true) { readLoop(s) }
    }

    private fun disconnect(s: BluetoothSocket?) {
        synchronized(this) {
            if (s != null && socket === s) { socket = null; out = null }
        }
        runCatching { s?.close() }
        post { listener.onProgress(false, null); listener.onState(ConnState.IDLE) }
    }

    private fun readLoop(s: BluetoothSocket) {
        val inp = DataInputStream(BufferedInputStream(s.inputStream, 8192))
        try {
            while (true) {
                when (inp.readByte().toInt()) {
                    1 -> { val t = readStr(inp); post { listener.onText(t) } }
                    2 -> receiveFile(inp)
                    else -> throw IOException("Protokol tidak dikenal")
                }
            }
        } catch (e: IOException) {
            // putus -> loop connect akan mencoba lagi
        } finally {
            disconnect(s)
        }
    }

    private fun receiveFile(inp: DataInputStream) {
        val name = readStr(inp)
        val size = inp.readLong()
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "received").apply { mkdirs() }
        val file = uniqueFile(dir, name)
        var got = 0L
        var last = -1
        try {
            file.outputStream().use { o ->
                val buf = ByteArray(8192)
                while (got < size) {
                    val n = inp.read(buf, 0, minOf(buf.size.toLong(), size - got).toInt())
                    if (n < 0) throw EOFException()
                    o.write(buf, 0, n)
                    got += n
                    val pct = if (size > 0) (got * 100 / size).toInt() else 100
                    if (pct != last) { last = pct; post { listener.onProgress(false, pct / 100f) } }
                }
            }
        } catch (e: IOException) {
            file.delete(); throw e
        }
        post { listener.onProgress(false, null); listener.onFile(file.name, file, size) }
    }

    fun sendText(text: String): Boolean = synchronized(writeLock) {
        val o = out ?: return false
        try {
            o.writeByte(1); writeStr(o, text); o.flush(); true
        } catch (e: IOException) { disconnect(socket); false }
    }

    fun sendFile(file: File, displayName: String): Boolean = synchronized(writeLock) {
        val o = out ?: return false
        try {
            val size = file.length()
            o.writeByte(2); writeStr(o, displayName); o.writeLong(size)
            file.inputStream().use { i ->
                val buf = ByteArray(8192)
                var sent = 0L
                var last = -1
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    sent += n
                    val pct = if (size > 0) (sent * 100 / size).toInt() else 100
                    if (pct != last) { last = pct; post { listener.onProgress(true, pct / 100f) } }
                }
            }
            o.flush()
            post { listener.onProgress(true, null) }
            true
        } catch (e: IOException) {
            post { listener.onProgress(true, null) }
            disconnect(socket); false
        }
    }

    private fun writeStr(o: DataOutputStream, s: String) {
        val b = s.toByteArray(Charsets.UTF_8)
        o.writeInt(b.size); o.write(b)
    }

    private fun readStr(i: DataInputStream): String {
        val n = i.readInt()
        if (n < 0 || n > 4_000_000) throw IOException("Panjang tidak valid")
        val b = ByteArray(n); i.readFully(b)
        return String(b, Charsets.UTF_8)
    }
}

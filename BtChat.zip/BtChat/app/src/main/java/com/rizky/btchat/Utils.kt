package com.rizky.btchat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.util.Locale

fun uniqueFile(dir: File, rawName: String): File {
    val name = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = name.substringBeforeLast('.', name)
    val ext = name.substringAfterLast('.', "")
    var i = 1
    while (f.exists()) {
        f = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
        i++
    }
    return f
}

fun formatSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
}

fun mimeOf(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
}

fun isImage(name: String) = mimeOf(name).startsWith("image/")

private fun sampleSize(w: Int, h: Int, max: Int): Int {
    var s = 1
    while (w / (s * 2) >= max && h / (s * 2) >= max) s *= 2
    return s
}

/** Decode gambar dari Uri (galeri) dengan ukuran terkontrol + koreksi rotasi EXIF. */
fun decodeUri(ctx: Context, uri: Uri, max: Int): Bitmap? {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0) return null
    val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, max) }
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
    val deg = runCatching {
        cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
    }.getOrDefault(0)
    return if (deg != 0) {
        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
    } else bmp
}

fun decodeFile(path: String, max: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0) return null
    val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, max) }
    return BitmapFactory.decodeFile(path, opts)
}
